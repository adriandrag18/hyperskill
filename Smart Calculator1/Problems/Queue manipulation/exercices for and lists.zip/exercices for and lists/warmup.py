numbers = [1, 2, 3, 4, 5, 6, 7, 3245, 31, 2, 51, 1, 41, 51, 324, 5, 1, 512]

# calculeaza si printeaza suma elementelor din lista
# calculeaza si printeaza media elemetelor
# HINT: numarul elemetelor dintr o lista se obtine cu len(numele listei), in cazul asta len(numbers)
