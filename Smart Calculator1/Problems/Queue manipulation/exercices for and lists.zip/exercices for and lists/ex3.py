my_list = [el for el in "isubvaosvasuvbas;jovbasvbquipb;lkjnvasujvbauosvba;jlsvb"]  # tot o lista
# poti sa ignori sintaza asta ciudata pentru moment

# 1. numara de cate ori apare litera "i"
# 2. Hard: gaseste caracterul care apare cel mai des
