lst = [1, 2, 3, 4, 5]

# verifica daca un numar introdus de utilizator este in lista si daca este printeaza pozitia pe
# care se gaseste
