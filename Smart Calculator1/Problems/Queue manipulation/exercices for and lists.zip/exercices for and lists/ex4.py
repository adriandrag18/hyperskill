# cere utilizatorului sa introduca niste numere (programul se va opri din citire cand -1 este
# introdus) si creaza o lista cu toate numerele pare
