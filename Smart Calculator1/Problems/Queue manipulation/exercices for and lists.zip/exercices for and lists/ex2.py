my_list = list(range(-10, 77, 4))

# cere utilizatorului un numar si verifica daca exista in lista, daca da sterge l
